package main

import "testing"

func TestFailed(t *testing.T) {
	t.Fatal("Failed")
}
