package application

const (
	Secret = "secret"
)