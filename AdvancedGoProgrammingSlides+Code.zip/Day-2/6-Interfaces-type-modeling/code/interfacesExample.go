package main

import (
	"fmt"
)

// type alias
type Helper = interface {
	Help() string
}

type HelpString string

func (hs HelpString) Help() string  {
	return string(hs)
}

type UnHelpString struct {}

func (uhs *UnHelpString) Help() string  {
	return "I cannot help you"
}

// Compile time check
var _ = Helper(HelpString(""))

func main()  {
	var h Helper = HelpString("Please help me learn Golang")
	fmt.Println(h.Help())

	var explicit = interface {Help() string}.Help(h)
	fmt.Println(explicit)

	// Polymorphism
	var helpers = []Helper{
		HelpString("Please help me learn Golang"),
		&UnHelpString{},
	}

	// won't work as []Helper is not ...interface{}
	//fmt.Println(helpers...)

	// works
	fmt.Println(helpers)

	for _, helper := range helpers {
		fmt.Println(helper.Help())
	}

	var h2 interface{} = HelpString("Please help me learn Golang")

	// runtime check
	n, ok := h2.(Helper)
	fmt.Println(n, ok)

	// panics
	//var _ = h2.(string)
}