package web

import "Advanced-Go-Programming-in-7-Days/Day-7/1-Task-Overview/code/easy-issues/domain"

// Parse url query into ListOptions
func ParseQuery(ulrString string) *domain.ListOptions  {
}