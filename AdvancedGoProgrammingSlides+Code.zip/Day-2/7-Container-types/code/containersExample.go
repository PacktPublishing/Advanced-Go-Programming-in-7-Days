package main

import (
	"unsafe"
	"fmt"
)

func ReadMemory(ptr unsafe.Pointer, size uintptr) []byte {
	out := make([]byte, size)
	for i := range out {
		out[i] = *((*byte)(unsafe.Pointer(uintptr(ptr) + uintptr(i))))
	}
	return out
}

// internal representation
type MySlice struct {
	elems unsafe.Pointer
	len int
	cap int
}

const e = 2

func main()  {
	var mapping = make(map[int]int)
	mapping[e] = e
 var myptr = &ma[1]

	value, ok := mapping[e]
	fmt.Println(value, ok)

	//var array = [...]byte{1,2,3}
	var array2 = [...]byte{2: 1, 3: 2,4: 3}
	fmt.Println(array2) // [0 0 1 2 3]
	// _ = array2[-1] no negative index

	// build-in methods
	fmt.Println(len(array2), cap(array2)) // 5 5
	fmt.Println(len(mapping)) // 1
	delete(mapping, e)
	fmt.Println(len(mapping)) // 0

	s := new(MySlice)
	s.elems = unsafe.Pointer(&array2)
	s.len = len(array2)
	s.cap = cap(array2)
	fmt.Println(ReadMemory(unsafe.Pointer(s), 24))
	fmt.Println(ReadMemory(unsafe.Pointer(s.elems), 5)) //[0 0 1 2 3]
}
