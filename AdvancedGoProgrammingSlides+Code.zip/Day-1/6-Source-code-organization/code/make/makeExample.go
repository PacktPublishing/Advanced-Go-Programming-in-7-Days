package main

import (
	"github.com/golang/glog"
)

func main()  {
	glog.Warning("Warning before exit")
}
