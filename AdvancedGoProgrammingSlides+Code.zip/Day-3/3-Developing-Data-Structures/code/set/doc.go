/*
set is a Go library that implements a Set data structure
*/
package set