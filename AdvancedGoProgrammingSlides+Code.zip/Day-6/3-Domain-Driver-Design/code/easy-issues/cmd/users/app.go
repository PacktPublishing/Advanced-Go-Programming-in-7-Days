package main

import (
	"Advanced-Go-Programming-in-7-Days/Day-6/3-Domain-Driver-Design/code/easy-issues/persistence/memory"
	"fmt"
	"Advanced-Go-Programming-in-7-Days/Day-6/3-Domain-Driver-Design/code/easy-issues/application"
	"Advanced-Go-Programming-in-7-Days/Day-6/3-Domain-Driver-Design/code/easy-issues/domain"
	"net/http"
	"time"
	"log"
	"Advanced-Go-Programming-in-7-Days/Day-6/3-Domain-Driver-Design/code/easy-issues/web/controller"
)

func main()  {
	userRepo := memory.NewUserRepository()

	userService := application.UserService{
		UsersRepository: userRepo,
	}

	userController := controller.UserController{
		UserService: userService,
	}

	for i:=0;i<10;i+=1 {
		userService.Create(&domain.User{Name: fmt.Sprintf("User_%d", i)})
	}

	mux := http.NewServeMux()
	mux.HandleFunc("/api/users", userController.List)

	server := &http.Server{
		Addr:           ":8090",
		Handler:        mux,
		ReadTimeout:  5 * time.Second,
		WriteTimeout: 10 * time.Second,
		IdleTimeout:  120 * time.Second,
		MaxHeaderBytes: 1 << 20,
	}

	log.Fatal(server.ListenAndServe())
}
